import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Event } from '../event';
const API = environment.ApiUrl
@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  constructor(private http:HttpClient) { }
  create(doc:Event){
    return this.http.post(API+'/Event',doc)
  }
  update(id:string,doc:Event){
    return this.http.put(API+'/Event/'+id,doc)
  }
  delete(id:string){
    return this.http.delete(API+ '/Event/'+id)
  }
  get_All(){
    return this.http.get(API+'/Event')
  }
}
