import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventRoutingModule } from './event-routing.module';
import { ListDocumentsComponent } from './list-documents/list-documents.component';
import { DetailDocumentComponent } from './detail-document/detail-document.component';
import { EditDocumentComponent } from './edit-document/edit-document.component';
import { DeleteDocumentComponent } from './delete-document/delete-document.component';
import { AddDocumentComponent } from './add-document/add-document.component';
import { NgxDropzoneModule } from 'ngx-dropzone';


@NgModule({
  declarations: [
    ListDocumentsComponent,
    DetailDocumentComponent,
    EditDocumentComponent,
    DeleteDocumentComponent,
    AddDocumentComponent
  ],
  imports: [
    CommonModule,
    EventRoutingModule,
    NgxDropzoneModule
  ],
  exports:[
    DeleteDocumentComponent,
    EditDocumentComponent,
    AddDocumentComponent,
    AddDocumentComponent
  ]
})
export class EventModule { }
