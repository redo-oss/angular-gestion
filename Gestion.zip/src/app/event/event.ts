export class Event {
    type_zone?: string;
    type_objet?: string;
    ref_objet?: string;
    event?: string;
    etat?: string;
    date_debut?: Date;
    date_fin?: Date;
    image?:string;
    _id?:string;
}
