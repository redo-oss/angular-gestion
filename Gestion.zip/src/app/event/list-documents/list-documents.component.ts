import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Event } from '../event';
@Component({
  selector: 'app-list-documents',
  templateUrl: './list-documents.component.html',
  styleUrls: ['./list-documents.component.scss']
})
export class ListDocumentsComponent implements OnInit {
  public Events:Event[]
  constructor( private modal:NgbModal) {
    this.Events = [new Event()]
   }

  ngOnInit(): void {
   
    
  }
  create(content:any){
   
    this.modal.open(content).result.then((result:any)=>{
      console.log('result',result)
     
      
    },(reason:any)=>{
      console.log('reason',reason)
    })
  }
  view(content:any){
   
    this.modal.open(content).result.then((result:any)=>{
      console.log('result',result)
     
      
    },(reason:any)=>{
      console.log('reason',reason)
    })
  }
  delete(content:any){
   
    this.modal.open(content).result.then((result:any)=>{
      console.log('result',result)
     
      
    },(reason:any)=>{
      console.log('reason',reason)
    })
  }
  update(content:any){
   
    this.modal.open(content).result.then((result:any)=>{
      console.log('result',result)
     
      
    },(reason:any)=>{
      console.log('reason',reason)
    })
  }
  

}
