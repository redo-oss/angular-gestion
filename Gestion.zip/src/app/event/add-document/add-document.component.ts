import { Component, OnInit } from '@angular/core';
import { DocumentService } from '../service/document.service';
import { Event } from '../event';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-document',
  templateUrl: './add-document.component.html',
  styleUrls: ['./add-document.component.scss']
})
export class AddDocumentComponent implements OnInit {
  public formGroup: FormGroup
  files: File[] = [];
  
  constructor(private DocumentService: DocumentService) {
    this.formGroup = new FormGroup({
      type_zone: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^[a-z0-9]$/)]),
      type_objet: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^[a-z0-9]$/)]),
      ref_objet: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^[a-z0-9]$/)]),
      event: new FormControl(null, [
        Validators.required
      ]),
      etat: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^[a-z0-9]$/)]),
      date_debut: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/)]),
      date_fin: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/)]),
    })
  }

  ngOnInit(): void {

  }
 

  onSelect(event: any) {
    console.log(event);
    this.files.push(...event.addedFiles);
  }

  onRemove(event: any) {
    console.log(event);
    this.files.splice(this.files.indexOf(event), 1);
  }

}
