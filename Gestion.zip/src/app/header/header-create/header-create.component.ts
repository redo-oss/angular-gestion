import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-create',
  templateUrl: './header-create.component.html',
  styleUrls: ['./header-create.component.scss']
})
export class HeaderCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
