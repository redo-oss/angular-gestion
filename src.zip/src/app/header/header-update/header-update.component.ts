import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-update',
  templateUrl: './header-update.component.html',
  styleUrls: ['./header-update.component.scss']
})
export class HeaderUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
