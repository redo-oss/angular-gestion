import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-delete',
  templateUrl: './header-delete.component.html',
  styleUrls: ['./header-delete.component.scss']
})
export class HeaderDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
