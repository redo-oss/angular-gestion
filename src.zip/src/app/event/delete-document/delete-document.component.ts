import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-document',
  templateUrl: './delete-document.component.html',
  styleUrls: ['./delete-document.component.scss']
})
export class DeleteDocumentComponent implements OnInit {

  @Input() modal: any
  @Input() id: string;
  @Input() subject: string
  constructor() {
    this.id = '';
    this.subject = '';
  }

  ngOnInit(): void {
    console.log(this.id)
  }
  delete() {
    

  }

}
