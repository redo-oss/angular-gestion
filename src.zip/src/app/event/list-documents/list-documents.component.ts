import { Component, DoCheck, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Event } from '../event';
import { DocumentService } from '../service/document.service';
@Component({
  selector: 'app-list-documents',
  templateUrl: './list-documents.component.html',
  styleUrls: ['./list-documents.component.scss']
})
export class ListDocumentsComponent implements OnInit, DoCheck {
  public Events: Event[]

  constructor(private modal: NgbModal, private DocumentService: DocumentService) {
    this.Events = [new Event()]
    this.event = new Event()
  }

  ngOnInit(): void {


  }

  ngDoCheck() {
    if (this.DocumentService.Event) {
      this.Events = this.DocumentService.Event
    }
  }
  toDateIKnow(obj: any) {
  
    return new Date(obj?.year,obj?.month,obj?.day);
  }

  create(content: any) {

    this.modal.open(content).result.then((result: any) => {
      console.log('result', result)


    }, (reason: any) => {
      console.log('reason', reason)
    })
  }
  view(content: any) {

    this.modal.open(content).result.then((result: any) => {
      console.log('result', result)


    }, (reason: any) => {
      console.log('reason', reason)
    })
  }
  delete(content: any) {

    this.modal.open(content).result.then((result: any) => {
      console.log('result', result)


    }, (reason: any) => {
      console.log('reason', reason)
    })
  }
  public event: Event;
  update(content: any, event: Event) {
    this.event = event
    this.modal.open(content).result.then((result: any) => {
      console.log('result', result)


    }, (reason: any) => {
      console.log('reason', reason)
    })
  }


}
