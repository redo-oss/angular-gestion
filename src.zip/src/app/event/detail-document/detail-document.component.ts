import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-document',
  templateUrl: './detail-document.component.html',
  styleUrls: ['./detail-document.component.scss']
})
export class DetailDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
